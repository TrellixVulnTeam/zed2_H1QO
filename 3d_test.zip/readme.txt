http://www.open3d.org/docs/latest/tutorial/ReconstructionSystem/register_fragments.html
https://github.com/intel-isl/Open3D.git
